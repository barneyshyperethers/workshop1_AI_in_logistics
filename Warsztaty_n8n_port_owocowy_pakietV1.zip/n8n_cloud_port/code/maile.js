if($json.nextPageToken)throw Error('Ponad 100 maili: zawęź wyszukiwanie albo dodaj paginację');
const src=$('Indeks archiwum').first().json;
const known=new Set(src.archive_files.map(x=>x.name.match(/__([a-f0-9]+)\.json$/)?.[1]).filter(Boolean));
const messages=($json.messages||[]).filter(x=>!known.has(x.id));
return messages.length?messages.map(m=>({json:{gmail_id:m.id,has_mail:true},pairedItem:{item:0}})):[{json:{has_mail:false},pairedItem:{item:0}}];