const m=$('Waliduj AI').item.json;
if($json.id!==m.gmail_id||typeof $json.raw!=='string'||!$json.raw)throw Error('Brak oryginalnego RAW Gmail');
const bytes=Buffer.from($json.raw,'base64url');
if(bytes.length>2*1024*1024)throw Error('Demo: EML ponad 2 MiB');
const hash=require('crypto').createHash('sha256').update(bytes).digest('hex');
const name=m.order_id+'__'+m.delivery_id+'__'+m.gmail_id;
return {json:{...m,base_name:name,raw_sha256:hash},binary:{data:{data:bytes.toString('base64'),mimeType:'message/rfc822',fileName:name+'.eml'}}};