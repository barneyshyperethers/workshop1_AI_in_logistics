if($json.nextPageToken||$json.incompleteSearch)throw Error('Lista raportu niepelna: potrzebna paginacja');
const files=($json.files||[]).filter(x=>x.name.endsWith('.json'));
return files.length?files.map(f=>({json:{file_id:f.id,file_created_at:f.createdTime,empty:false},pairedItem:{item:0}})):[{json:{empty:true},pairedItem:{item:0}}];