const files=$json.files||[];
if($json.nextPageToken||$json.incompleteSearch)throw Error('Lista Drive niepelna: zmniejsz demo lub dodaj paginacje');
return [{json:{...$('Ustawienia i plan').first().json,archive_files:files}}];