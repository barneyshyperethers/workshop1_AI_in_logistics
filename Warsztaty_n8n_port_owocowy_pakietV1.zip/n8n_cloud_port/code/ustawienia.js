// Zmien tylko wartosci w cudzyslowach.
return [{json:{target_file_id:'WKLEJ_ID_TARGET_JSON',counted_folder_id:'WKLEJ_ID_FOLDERU_ZLICZONE',gmail_query:'label:PORT_AUDYT'}}];