// Shared source embedded in n8n Code nodes. No filesystem and no external packages.
const FRUITS = {jablka:['jabłka','jabłek','jablka','jablek','apple','apples'],banany:['banany','bananów','bananow','banana','bananas'],ananasy:['ananasy','ananasów','ananasow','ananas','pineapple','pineapples']};
function checkTarget(t) {
  if (!t || !/^[A-Z0-9-]{1,60}$/.test(t.order_id||'')) throw Error('Niepoprawny order_id');
  if (t.unit!=='szt' || Object.keys(t.items||{}).sort().join()!==Object.keys(FRUITS).sort().join()) throw Error('Target wymaga trzech owocow i unit=szt');
  if (Object.values(t.items).some(n=>!Number.isSafeInteger(n)||n<0||n>10000000)) throw Error('Niepoprawne ilosci target');
  if (!Array.isArray(t.allowed_senders)||!t.allowed_senders.length||t.allowed_senders.some(x=>typeof x!=='string'||!x.includes('@'))) throw Error('Wpisz rzeczywisty adres allowed_senders');
  return t;
}
function header(payload,name) {return (payload.headers||[]).find(h=>h.name.toLowerCase()===name.toLowerCase())?.value||'';}
function plainText(part) {
  if (part.filename) return '';
  if (part.mimeType==='text/plain') {
    const ct=header(part,'content-type');
    const charset=ct.match(/charset\s*=\s*"?([^;"\s]+)/i)?.[1]?.toLowerCase();
    if (charset && !['utf-8','utf8','us-ascii'].includes(charset)) throw Error('Nieobslugiwany charset: '+charset);
    return part.body?.data ? Buffer.from(part.body.data,'base64url').toString('utf8') : '';
  }
  return (part.parts||[]).map(plainText).filter(Boolean).join('\n');
}
function parseMail(message,target,archiveFiles=[]) {
  const subject=header(message.payload||{},'subject');
  const from=header(message.payload||{},'from');
  const sender=(from.match(/<([^>]+)>/)?.[1]||from).trim().toLowerCase();
  const match=subject.match(/^AUDYT ([A-Z0-9-]+) (DOK-[1-5]) (KONT-[A-Z0-9-]+)$/);
  const m={eligible:false,gmail_id:message.id||'',subject,sender,reason:''};
  if (!m.gmail_id || !match || match[1]!==target.order_id) return {...m,reason:'Inny temat lub zamowienie'};
  if (!target.allowed_senders.map(x=>x.toLowerCase()).includes(sender)) return {...m,reason:'Nadawca spoza allowed_senders'};
  let body;
  try {body=plainText(message.payload||{});}catch(e){return {...m,reason:e.message};}
  if (!body.trim() || body.length>30000) return {...m,reason:'Brak text/plain lub ponad 30000 znakow'};
  const delivery_id=match[3];
  // Names encode both Gmail message ID and business delivery ID.
  const prefix=target.order_id+'__'+delivery_id+'__';
  if (archiveFiles.some(f=>f.name.startsWith(prefix)&&f.name.endsWith('.json'))) return {...m,reason:'Dostawa jest juz w archiwum'};
  return {...m,eligible:true,body,order_id:match[1],dock:match[2],delivery_id,
    message_id:header(message.payload||{},'message-id'),target};
}
function validate(a,m) {
  if (!a||a.is_audit!==true||a.needs_review!==false) return 'Brak jednoznacznego audytu: '+(a?.reason||'');
  for(const k of ['order_id','dock','delivery_id']) if(a[k]!==m[k]) return 'Niespojny '+k;
  if(!Array.isArray(a.items)||!a.items.length) return 'Brak owocow';
  if(!Array.isArray(a.iso)||a.iso.some(x=>typeof x!=='string'||!m.body.includes(x))) return 'ISO bez cytatu';
  const seen=new Set();
  for(const i of a.items) {
    if(!i||!FRUITS[i.fruit]||seen.has(i.fruit))return 'Nieznany lub powtorzony owoc';
    seen.add(i.fruit);
    if(!Number.isSafeInteger(i.quantity)||i.quantity<0||i.quantity>10000000||i.unit!=='szt')return 'Niepoprawna ilosc lub jednostka';
    if(typeof i.evidence!=='string'||!i.evidence||!m.body.includes(i.evidence))return 'Brak cytatu w mailu';
    const ev=i.evidence.toLowerCase(),compact=ev.replace(/[\s\u00a0]/g,'');
    if(/[-−]\d|\d[.,]\d/.test(compact))return 'Ujemna lub niejednoznaczna liczba';
    if(!new RegExp('(?<!\\d)'+i.quantity+'(?!\\d)').test(compact))return 'Ilosc bez potwierdzenia w cytacie';
    const words=ev.split(/[^\p{L}]+/u);
    if(!FRUITS[i.fruit].some(x=>words.includes(x)))return 'Owoc bez potwierdzenia w cytacie';
    if(!/\b(szt\.?|sztuk[a-z]*|pieces?)\b/.test(ev))return 'Brak jednostki sztuk w cytacie';
  }
  return '';
}
function mock(m) {
  const names={'Jabłka':'jablka','Banany':'banany','Ananasy':'ananasy'};
  const items=[];let bad=false;
  for(const line of m.body.split(/\r?\n/)) {
    const x=line.match(/^(Jabłka|Banany|Ananasy): (\d+) szt\.$/);
    if(x)items.push({fruit:names[x[1]],quantity:Number(x[2]),unit:'szt',evidence:line});
    else if(/^(Jabłka|Banany|Ananasy|Gruszki):/.test(line))bad=true;
  }
  return {is_audit:true,order_id:m.order_id,dock:m.dock,delivery_id:m.delivery_id,
    items,iso:[...m.body.matchAll(/ISO \d{4,5}(?::\d{4})?/g)].map(x=>x[0]),
    needs_review:bad||!items.length,reason:'SYMULACJA bez AI'};
}
function readResponse(r) {
  if(r.status!=='completed')throw Error('Odpowiedz AI nie jest completed');
  const content=(r.output||[]).flatMap(x=>x.content||[]);
  if(content.some(x=>x.type==='refusal'))throw Error('Odmowa AI');
  const output=content.filter(x=>x.type==='output_text');
  if(output.length!==1)throw Error('Oczekiwano jednego JSON');
  const a=output[0].text;
  return typeof a==='string'?JSON.parse(a):a;
}
function makeLedger(m,emlId,emlSha) {
  if(!emlId)throw Error('Brak ID zapisanego EML');
  return {schema_version:1,order_id:m.order_id,delivery_id:m.delivery_id,gmail_id:m.gmail_id,
    message_id:m.message_id,subject:m.subject,sender:m.sender,dock:m.dock,
    accepted_at:new Date().toISOString(),eml_file_id:emlId,raw_sha256:emlSha,
    analysis:m.analysis};
}
function aggregate(records,target) {
  const total={jablka:0,banany:0,ananasy:0},byGmail=new Set(),byDelivery=new Set(),warnings=[];
  let accepted=0,duplicates=0;
  const sorted=records.filter(r=>r&&!r.empty).sort((a,b)=>String(a._created_at||a.accepted_at||'').localeCompare(String(b._created_at||b.accepted_at||''))||String(a._file_id||'').localeCompare(String(b._file_id||'')));
  for(const r of sorted) {
    if(r.order_id!==target.order_id)continue;
    if(!r.gmail_id||!r.delivery_id||!r.eml_file_id||!r.raw_sha256||r.analysis?.needs_review!==false||r.analysis?.is_audit!==true)throw Error('Uszkodzony rekord archiwum');
    if(byGmail.has(r.gmail_id)){duplicates++;continue;}
    if(byDelivery.has(r.delivery_id)){warnings.push('Powtorzona dostawa '+r.delivery_id+' (Gmail '+r.gmail_id+') pominieta');duplicates++;continue;}
    const seen=new Set();
    if(!Array.isArray(r.analysis.items)||!r.analysis.items.length)throw Error('Brak pozycji archiwum');
    for(const i of r.analysis.items){
      if(!FRUITS[i.fruit]||seen.has(i.fruit)||!Number.isSafeInteger(i.quantity)||i.quantity<0||i.unit!=='szt')throw Error('Niepoprawna pozycja archiwum');
      seen.add(i.fruit);
    }
    byGmail.add(r.gmail_id);byDelivery.add(r.delivery_id);accepted++;
    for(const i of r.analysis.items)total[i.fruit]+=i.quantity;
  }
  return Object.keys(total).map(f=>({order_id:target.order_id,owoc:f,odebrano:total[f],target:target.items[f],
    brakuje:Math.max(target.items[f]-total[f],0),nadwyzka:Math.max(total[f]-target.items[f],0),
    status:total[f]<target.items[f]?'BRAK':total[f]>target.items[f]?'NADWYZKA':'OK',
    przyjete_maile:accepted,pominiete_duplikaty:duplicates,uwagi:warnings.join('; ')}));
}
const m=$json;return {json:{status:'completed',output:[{type:'message',content:[{type:'output_text',text:mock(m)}]}]}};