// Tylko 2 wartosci do zmiany. Calosc wykonuje sie w n8n Cloud.
const root_folder_id='WKLEJ_ID_FOLDERU_PORT';
const sender='TWOJ_ADRES@gmail.com';
if(root_folder_id.startsWith('WKLEJ')||sender.startsWith('TWOJ'))throw Error('Wpisz folder Drive i wlasny email');
const target={order_id:'ZAM-2026-001',unit:'szt',items:{jablka:2000,banany:3000,ananasy:5},allowed_senders:[sender]};
return [{json:{root_folder_id,target},binary:{data:{data:Buffer.from(JSON.stringify(target,null,2),'utf8').toString('base64'),mimeType:'application/json',fileName:'target.json'}}}];