# Warsztaty n8n Cloud Gmail i Google Drive

Cały warsztat wykonasz w przeglądarce. Potrzebujesz trial n8n Cloud, konta Google z Gmail i Google Drive oraz połączenia z internetem. Nie instalujesz żadnego oprogramowania.

## Kolejność

1. Utwórz trial n8n Cloud przez stronę n8n. Aktualne warunki sprawdź na ekranie rejestracji.
2. W Google Drive utwórz folder `Port_owocowy_demo`. Skopiuj ID folderu z końca adresu `/folders/ID`.
3. Importuj `workflows/00_Plan_w_chmurze.json` do pustego workflow w n8n.
4. W `Dane planu` zmień tylko ID folderu i swój adres Gmail. W obu węzłach Drive utwórz credential przez **Sign in with Google**. Używaj tego samego konta.
5. Kliknij **Execute workflow**. Powstaną `target.json` i folder `zliczone`. Z węzła `Zapisz te ID` skopiuj `target_file_id` i `counted_folder_id`. Generator uruchom tylko raz dla jednego zestawu.
6. Importuj `01_Gmail_AI_Cloud.json` do nowego pustego workflow. W `Ustawienia` wpisz te dwa ID.
7. W węzłach HTTP wybierz **Predefined Credential Type**, a następnie odpowiednio **Google Drive OAuth2 API** lub **Gmail OAuth2** i swój credential. W `Gmail nowy mail` wybierz ten sam Gmail. W `Zapisz EML` i `Zapisz rekord` wybierz Drive.
8. W `Ekstrakcja AI` wybierz **Use Gateway credits**. To kredyty na wywołania modelu, a nie n8n Assistant. Jeżeli model `gpt-4.1-mini` nie jest na liście Gateway, wybierz dostępny model obsługujący Responses API i JSON Schema. W razie potrzeby możesz wybrać własny credential OpenAI, również przez przeglądarkę.
9. W Gmail utwórz etykietę `PORT_AUDYT`. Utwórz filtr dla tematu `AUDYT ZAM-2026-001`, przypisujący tę etykietę. Obejmij także wcześniejsze pasujące maile.
10. Otwórz `Maile_testowe.html` w przeglądarce. Utwórz w Gmail pięć NOWYCH wiadomości (1–5), z dokładnymi tematami i treścią, wysyłając je ze swojego dozwolonego adresu do tej samej skrzynki. Sprawdź etykietę.
11. Wykonaj ręcznie **Start reczny**. Otwórz `Porownanie` i widok **Table**: oczekiwane ilości to **1500 jabłek, 3000 bananów, 0 ananasów**. Cztery maile zostaną zapisane; piąty opisuje puste palety.
12. Kliknij **Publish**, aby Gmail Trigger sprawdzał nowe wiadomości. Wysyłaj następne audyty. Workflow pobiera także starsze maile z etykietą, których nie ma jeszcze w archiwum. Jeśli otworzysz mail przed odczytem, nadal powinien być obsłużony: filtr czytania to **Unread and read emails**.

Szczegółowe pola, ilustracje i ćwiczenia są w PDF i samodzielnym pliku HTML instrukcji.

## Cztery workflow

| Plik | Zastosowanie |
| --- | --- |
| `00_Plan_w_chmurze.json` | Jednorazowo tworzy target i folder zliczone na Drive |
| `01_Gmail_AI_Cloud.json` | Właściwy warsztat z AI przez Gateway lub własny klucz |
| `02_Gmail_SYMULACJA_Cloud.json` | Ten sam proces bez modelu, do testowania wzorca i plików |
| `03_Tylko_raport.json` | Odczytuje istniejące rekordy z Drive, bez czytania Gmaila i bez wywołań AI |

W każdym używanym workflow wpisz te same ID i wybierz credentials. Warianty AI i SYMULACJA uruchamiaj osobno; nie publikuj ich równocześnie dla tej samej skrzynki. Symulacja jest parserem konkretnych wierszy, nie analizą AI.

## Przechowywanie

`target.json` oraz folder `zliczone` znajdują się obok siebie na Google Drive. n8n Cloud nie jest dyskiem z trwałymi dowolnymi katalogami. Wyniki wykonań i pliki binarne w historii nie zastępują trwałego archiwum.

Każdy przyjęty audyt tworzy na Drive parę:

- `ZAM-2026-001__KONT-001__<GMAIL_ID>.eml` — oryginalne bajty RAW pobrane z Gmaila;
- `ZAM-2026-001__KONT-001__<GMAIL_ID>.json` — zaakceptowane ilości, deklaracje ISO i ID kopii EML.

Najpierw zapisywany jest EML, a następnie JSON. Dopiero JSON stanowi podstawę zliczenia. Raport sumuje unikalne ID wiadomości i dostaw z tych zapisanych rekordów. Skasowanie wiadomości w Gmail nie odejmuje wcześniej przyjętych ilości. Nie usuwaj ani nie edytuj przyjętych rekordów w Drive. Zmiana samej nazwy lub usunięcie plików archiwum może zaburzyć raport; warsztat nie implementuje niezależnego dziennika niezmienności.

Drive dopuszcza identyczne nazwy plików. Równoczesne wykonania mogą utworzyć dodatkowe fizyczne kopie, ale raport liczy daną wiadomość i dostawę raz. Dla powtórzonej dostawy przyjmuje najwcześniej zapisany rekord. To nie jest transakcyjny magazyn produkcyjny.

## Ćwiczenia

1. Po mailach 1–5: **1500 / 3000 / 0**.
2. Po mailu 6: **2000 / 3000 / 5**, wszystkie statusy OK.
3. Po mailu 7: **2000 / 3200 / 7**, nadwyżki 200 bananów i 2 ananasy.
4. Ponowne ręczne wykonanie: ilości nie rosną.
5. Kolejny mail o KONT-001: nie zlicza ponownie tej samej dostawy.
6. Usunięcie z Gmail jednego przyjętego maila: uruchom `03_Tylko_raport`; ilości pozostają.
7. Kilogramy, gruszki, puste palety lub polecenie zmiany zasad: brak zliczenia, powód w wyjściu `Sprawdz wzorzec` lub `Waliduj AI`.

Maile odrzucone nie są dopisywane do archiwum i mogą być analizowane ponownie w kolejnym skanie. Aby nie powtarzać kosztu AI dla takiego maila, usuń mu etykietę `PORT_AUDYT` po sprawdzeniu. Błąd usługi napraw, a następnie ponów cały proces ręcznie; nie dodawaj ilości ręcznie.

## Opcjonalny lokalny JSON

Możesz wgrać własny plik JSON do folderu Drive przyciskiem **New → File upload** i ustawić jego ID jako `target_file_id`. Nie wpisuj ścieżki `C:\...` w n8n Cloud. Nie zamieniaj JSON na dokument Google Docs. Bez lokalnego edytora możesz zmienić wartości w `Dane planu` i utworzyć nowy plik w chmurze. Przykład JSON znajduje się w `pliki/target.json`.

## Ograniczenia demonstracji

- Ilości są deklaracjami z maili; nie potwierdzają fizycznego przyjęcia.
- ISO jest informacją z treści; autentyczność i ważność certyfikatów nie są weryfikowane.
- Obsługiwane są części text/plain w UTF-8 lub ASCII. Maile wyłącznie HTML, załączniki i OCR nie są analizowane.
- Limit demonstracyjny: 100 wiadomości w wyszukiwaniu, jedna strona do 1000 rekordów Drive, EML do 2 MiB. Jeśli API zwróci kolejną stronę, proces zgłasza błąd zamiast pokazać niepełną sumę. To warsztat dla małej skrzynki testowej.
- Konto Google Workspace może wymagać zgody administratora na połączenie OAuth.
- Trial i kredyty mają limity. Sprawdź aktualny stan w panelu. Po zakończeniu trial dane archiwalne na Drive pozostają, ale workflow n8n nie będzie dalej działał bez aktywnego planu.

Kod logiki i struktura workflow są sprawdzane offline. Podczas tworzenia tej wersji nie logowano się do Twojego n8n Cloud ani Google i nie wykonano rzeczywistych wywołań Gateway. Przed wydarzeniem wykonaj w swojej instancji pięć początkowych maili i test nadwyżki. Plik `testy/sprawdz_logike.cjs` służy autorowi materiałów, nie jest wymaganiem dla uczestnika.
