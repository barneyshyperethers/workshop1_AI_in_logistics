// Maintainer verification only. Participants do not need Node or local tools.
const fs=require('fs'),path=require('path'),assert=require('assert'),crypto=require('crypto');
const root=path.resolve(__dirname,'..'),F=require('../code/funkcje.js');
const cases=JSON.parse(fs.readFileSync(path.join(__dirname,'maile.json'),'utf8'));
const target={order_id:'ZAM-2026-001',unit:'szt',items:{jablka:2000,banany:3000,ananasy:5},allowed_senders:['demo@example.test']};
let passed=0;
function test(name,fn){fn();passed++;console.log('OK',name);}
function message(i,overrides={}){
 const c=cases[i-1];return {id:'a'+String(i).padStart(5,'0'),payload:{mimeType:'text/plain',headers:[{name:'Subject',value:c.subject},{name:'From',value:'Demo <demo@example.test>'},{name:'Message-ID',value:'<'+i+'@test>'}],body:{data:Buffer.from(c.body,'utf8').toString('base64url')}},...overrides};
}
function valid(i){const m=F.parseMail(message(i),target);m.analysis=F.mock(m);return m;}
function ledger(i,time=i){const m=valid(i);assert.equal(F.validate(m.analysis,m),'');return {...F.makeLedger(m,'drive-eml-'+i,'sha'+i),_created_at:new Date(1000*time).toISOString(),_file_id:'file'+i};}
function totals(records){return F.aggregate(records,target).map(r=>r.odebrano);}
function runCode(file,data,refs={},all){
 const script=fs.readFileSync(path.join(root,'code',file+'.js'),'utf8');
 const $=(name)=>({first:()=>({json:refs[name]}),item:{json:refs[name]},itemMatching:i=>({json:Array.isArray(refs[name])?refs[name][i]:refs[name]})});
 return new Function('$json','$input','$','require','Buffer',script)(data,{all:()=>all||[{json:data}],first:()=>({json:data})},$,require,Buffer);
}
test('target validation',()=>{F.checkTarget(target);assert.throws(()=>F.checkTarget({...target,unit:'kg'}));assert.throws(()=>F.checkTarget({...target,items:{...target.items,jablka:-1}}));});
test('five initial emails',()=>{let records=[];for(let i=1;i<=5;i++){const m=valid(i);if(!F.validate(m.analysis,m))records.push(ledger(i));}assert.equal(records.length,4);assert.deepEqual(totals(records),[1500,3000,0]);});
test('fulfilment and excess',()=>{const r=[1,2,3,4,6].map(i=>ledger(i));assert.deepEqual(totals(r),[2000,3000,5]);r.push(ledger(7));assert.deepEqual(totals(r),[2000,3200,7]);assert.deepEqual(F.aggregate(r,target).map(x=>x.nadwyzka),[0,200,2]);});
test('duplicate copies from parallel executions',()=>{const r=[1,2,3,4].map(i=>ledger(i));for(let i=0;i<12;i++)r.push({...r[0],_file_id:'duplicate'+i});assert.deepEqual(totals(r),[1500,3000,0]);assert.equal(F.aggregate(r,target)[0].przyjete_maile,4);});
test('same delivery different Gmail ID counts once',()=>{const r=[ledger(1),{...ledger(1,2),gmail_id:'b999',_file_id:'later'}];assert.deepEqual(totals(r),[700,500,0]);assert.match(F.aggregate(r,target)[0].uwagi,/Powtorzona dostawa/);});
test('deletion in Gmail does not affect archive report',()=>{const archive=[1,2,3,4].map(i=>ledger(i));let inbox=[1,2,3,4,5];inbox=[];assert.deepEqual(totals(archive),[1500,3000,0]);});
test('bad units, unknown fruit and instruction rejected',()=>{for(const i of [5,8,10,11]){const m=valid(i);assert.ok(F.validate(m.analysis,m));}});
test('sender, subject and different order rejected',()=>{const m=message(1);m.payload.headers[1].value='attacker@example.test';assert.equal(F.parseMail(m,target).eligible,false);m.payload.headers[1].value='demo@example.test';m.payload.headers[0].value='Re: '+cases[0].subject;assert.equal(F.parseMail(m,target).eligible,false);assert.equal(F.parseMail(message(1),{...target,order_id:'ZAM-INNE'}).eligible,false);});
test('archive index blocks repeated business delivery',()=>{const m=message(9);assert.equal(F.parseMail(m,target,[{name:'ZAM-2026-001__KONT-001__a00001.json'}]).eligible,false);});
test('malformed model responses',()=>{for(const x of [{status:'incomplete'}, {status:'completed',output:[{content:[{type:'refusal'}]}]}, {status:'completed',output:[{content:[{type:'output_text',text:'bad-json'}]}]}])assert.throws(()=>F.readResponse(x));});
test('response string and parsed object supported',()=>{const a=valid(1).analysis;for(const text of [a,JSON.stringify(a)])assert.deepEqual(F.readResponse({status:'completed',output:[{content:[{type:'output_text',text}]}]}),a);});
test('negative and hallucinated quantities rejected',()=>{for(const change of [{quantity:-1},{quantity:1.5},{quantity:999999},{unit:'kg'},{evidence:'fake'}]){const m=valid(1);Object.assign(m.analysis.items[0],change);assert.ok(F.validate(m.analysis,m));}});
test('HTML only is review',()=>{const m=message(1);m.payload.mimeType='text/html';assert.equal(F.parseMail(m,target).eligible,false);});
test('exact RAW EML bytes and ledger ID retained',()=>{
 const m=valid(1);m.approved=true;
 const raw=Buffer.from('From: demo@example.test\r\nSubject: Test\r\n\r\nJabłka: 700 szt.\r\n','utf8');
 const out=runCode('eml',{id:m.gmail_id,raw:raw.toString('base64url')},{'Waliduj AI':m});
 assert.deepEqual(Buffer.from(out.binary.data.data,'base64'),raw);assert.equal(out.binary.data.mimeType,'message/rfc822');assert.equal(out.json.raw_sha256,crypto.createHash('sha256').update(raw).digest('hex'));
 const record=runCode('rekord',{id:'saved-eml-id'},{'Przygotuj EML':out.json});
 const decoded=JSON.parse(Buffer.from(record.binary.data.data,'base64').toString());assert.equal(decoded.eml_file_id,'saved-eml-id');assert.equal(decoded.gmail_id,m.gmail_id);
});
test('empty report and pagination guards',()=>{assert.deepEqual(totals([]),[0,0,0]);assert.throws(()=>runCode('pliki_raportu',{nextPageToken:'more'}));assert.throws(()=>runCode('maile',{nextPageToken:'more'}));assert.deepEqual(runCode('pliki_raportu',{files:[]})[0].json,{empty:true});});
test('Gmail list skips known message IDs before model calls',()=>{
 const refs={'Indeks archiwum':{archive_files:[{name:'ZAM-2026-001__KONT-001__a00001.json'}]}};
 const r=runCode('maile',{messages:[{id:'a00001'},{id:'a00002'}]},refs);
 assert.equal(r.length,1);assert.equal(r[0].json.gmail_id,'a00002');
 const empty=runCode('maile',{messages:[{id:'a00001'}]},refs);
 assert.equal(empty[0].json.has_mail,false);
});
test('all workflow links and Code syntax',()=>{
 for(const name of fs.readdirSync(path.join(root,'workflows'))){const w=JSON.parse(fs.readFileSync(path.join(root,'workflows',name)));const names=new Set(w.nodes.map(n=>n.name));for(const[a,c]of Object.entries(w.connections)){assert(names.has(a));for(const branch of c.main)for(const x of branch)assert(names.has(x.node));}for(const n of w.nodes)if(n.type==='n8n-nodes-base.code')new Function(n.parameters.jsCode);assert(!JSON.stringify(w).includes('localhost'));assert(!JSON.stringify(w).includes('http://archive'));}
});
const result={tests:passed,status:'passed',scope:'Offline JavaScript and workflow structure; Cloud OAuth, Google API, Gateway and real n8n import not executed.'};
fs.writeFileSync(path.join(__dirname,'wynik_testow.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
